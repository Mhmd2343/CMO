﻿using Microsoft.AspNetCore.Mvc;
using DeliveryAppSystem.Data;
using DeliveryAppSystem.Models;
using System.Linq;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Http;

namespace DeliveryAppSystem.Controllers
{
    public class AdminController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly PasswordHasher<Admin> _passwordHasher;

        public AdminController(ApplicationDbContext context)
        {
            _context = context;
            _passwordHasher = new PasswordHasher<Admin>();
        }

        // GET: Admin
        public IActionResult Index()
        {
            var admins = _context.Admins.ToList();
            return View(admins);
        }

        // GET: Admin/Create
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Admin/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Admin admin)
        {
            if (ModelState.IsValid)
            {
                // Hash and store password
                admin.PasswordHash = _passwordHasher.HashPassword(admin, admin.Password);
                admin.Password = null; // clear plaintext

                _context.Admins.Add(admin);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(admin);
        }

        // GET: Admin/Edit/5
        [HttpGet]
        public IActionResult Edit(int id)
        {
            var admin = _context.Admins.Find(id);
            if (admin == null) return NotFound();
            return View(admin);
        }

        // POST: Admin/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Admin admin)
        {
            if (id != admin.AdminId) return NotFound();
            if (ModelState.IsValid)
            {
                // If password field is filled, rehash
                if (!string.IsNullOrEmpty(admin.Password))
                {
                    admin.PasswordHash = _passwordHasher.HashPassword(admin, admin.Password);
                }
                admin.Password = null;

                _context.Admins.Update(admin);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }
            return View(admin);
        }

        // GET: Admin/Delete/5
        [HttpGet]
        public IActionResult Delete(int id)
        {
            var admin = _context.Admins.Find(id);
            if (admin == null) return NotFound();
            return View(admin);
        }

        // POST: Admin/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var admin = _context.Admins.Find(id);
            if (admin != null)
            {
                _context.Admins.Remove(admin);
                _context.SaveChanges();
            }
            return RedirectToAction(nameof(Index));
        }

        // GET: Admin/Login
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        // POST: Admin/Login
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(string email, string password)
        {
            var admin = _context.Admins.FirstOrDefault(a => a.Email == email);
            if (admin != null)
            {
                var result = _passwordHasher.VerifyHashedPassword(admin, admin.PasswordHash, password);
                if (result == PasswordVerificationResult.Success)
                {
                    HttpContext.Session.SetString("AdminId", admin.AdminId.ToString());
                    return RedirectToAction("Dashboard");
                }
            }
            ViewBag.Error = "Invalid email or password.";
            return View();
        }

        // GET: Admin/Dashboard
        [HttpGet]
        public IActionResult Dashboard()
        {
            var adminId = HttpContext.Session.GetString("AdminId");
            if (string.IsNullOrEmpty(adminId))
                return RedirectToAction("Login");

            ViewBag.AdminId = adminId;
            return View();
        }

        // GET: Admin/Logout
        public IActionResult Logout()
        {
            HttpContext.Session.Remove("AdminId");
            return RedirectToAction("Login");
        }
    }
}
