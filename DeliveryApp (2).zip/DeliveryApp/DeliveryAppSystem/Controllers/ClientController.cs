﻿using Microsoft.AspNetCore.Mvc;
using DeliveryAppSystem.Data;
using DeliveryAppSystem.Models;

namespace DeliveryAppSystem.Controllers
{
    public class ClientsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ClientsController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Dashboard()
        {
            return View();
        }
    }
}
