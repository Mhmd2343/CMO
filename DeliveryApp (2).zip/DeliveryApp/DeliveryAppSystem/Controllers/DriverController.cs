﻿using DeliveryAppSystem.Data;
using DeliveryAppSystem.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;

namespace DeliveryAppSystem.Controllers
{
    public class DriverController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly PasswordHasher<User> _passwordHasher;

        public DriverController(ApplicationDbContext context)
        {
            _context = context;
            _passwordHasher = new PasswordHasher<User>();
        }

        // GET: Driver/Register
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        // POST: Driver/Register
        [HttpPost]
        public IActionResult Register(string FirstName, string LastName, string Email, string Password, string ConfirmPassword, string VehicleType, string PlateNumber, string PricingType, decimal Price, string City, string WorkingHours)
        {
            if (Password != ConfirmPassword)
            {
                ViewBag.Error = "Passwords do not match!";
                return View();
            }

            // Check if the email is already used
            var existingUser = _context.Users.FirstOrDefault(u => u.Email == Email);
            if (existingUser != null)
            {
                ViewBag.Error = "User already exists!";
                return View();
            }

            // Save to DB
            var driver = new Driver
            {
                FirstName = FirstName,
                LastName = LastName,
                Email = Email,
                VehicleType = VehicleType,
                PlateNumber = PlateNumber,
                PricingType = PricingType,
                PricePerKm = Price,
                City = City,
                WorkingHours = WorkingHours
            };

            // Hash the password
            driver.PasswordHash = _passwordHasher.HashPassword(driver, Password);

            _context.Users.Add(driver);
            _context.SaveChanges();

            return RedirectToAction("Login", "User");
        }
    }
}
