﻿using DeliveryAppSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace DeliveryAppSystem.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Client> Clients { get; set; }
        public DbSet<Driver> Drivers { get; set; }
        public DbSet<Rating> Ratings { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<DeliveryRequest> DeliveryRequests { get; set; }

        public DbSet<RideRequest> RideRequests { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Rating>()
                .HasOne(r => r.Customer)
                .WithMany()
                .HasForeignKey(r => r.CustomerID)
                .OnDelete(DeleteBehavior.Cascade); // this is okay

            modelBuilder.Entity<Rating>()
                .HasOne(r => r.Driver)
                .WithMany()
                .HasForeignKey(r => r.DriverID)
                .OnDelete(DeleteBehavior.Restrict); // important: change from Cascade to Restrict
        }


    }
}
