﻿namespace DeliveryAppSystem.Models
{
    public class Client : User
    {
        public string Address { get; set; }
    }

}
