﻿using DeliveryAppSystem.Models;

public class Driver : User
{
    public string VehicleType { get; set; }
    public string PlateNumber { get; set; }
    public string PricingType { get; set; }  // "PerKM" or "PerDelivery"
    public string City { get; set; }
    public string WorkingHours { get; set; }
    public decimal FixedDeliveryPrice { get; set; }

    public decimal PricePerKm { get; set; }  // Price per kilometer

    // New field for average rating
    public decimal AverageRating { get; set; } = 0.0m;  // Default rating of 0
    public List<Rating> Ratings { get; set; }  // List of ratings the driver has received
    public decimal CalculatePrice(decimal distance)
    {
        if (PricingType == "PerKM")
        {
            return distance * PricePerKm;  // Assume PricePerKm is a field in your model
        }
        else if (PricingType == "PerDelivery")
        {
            return FixedDeliveryPrice;  // Assume FixedDeliveryPrice is a field in your model
        }
        else
        {
            return 0;
        }
    }

}
